from django.shortcuts import render
from django.shortcuts import render

def process_payment(request):
    return render(request, 'payments/process.html')
