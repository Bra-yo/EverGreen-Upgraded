
# orders/admin.py
from django.contrib import admin
from .models import Order

class SalespersonAdminSite(admin.AdminSite):
    site_header = "Salesperson Portal"
    site_title = "EverGreen Sales Portal"

class ManagerAdminSite(admin.AdminSite):
    site_header = "Manager Portal"
    site_title = "EverGreen Management"

# Instantiate the custom admin sites
salesperson_admin = SalespersonAdminSite(name='salesperson_admin')
manager_admin = ManagerAdminSite(name='manager_admin')

# Register models with custom admin sites
@admin.register(Order, site=salesperson_admin)
class SalespersonOrderAdmin(admin.ModelAdmin):
    list_display = ['user', 'property', 'status']

@admin.register(Order, site=manager_admin)
class ManagerOrderAdmin(admin.ModelAdmin):
    list_display = ['user', 'property', 'status', 'salesperson']

admin.site.register(Order, ManagerOrderAdmin)
