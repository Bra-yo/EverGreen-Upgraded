from django.shortcuts import render, get_object_or_404, redirect

from django.contrib.auth.decorators import login_required

from orders.models import Order
from properties.models import Property


@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'orders/my_orders.html', {'orders': orders})

@login_required
def add_to_cart(request, property_id):
    property = get_object_or_404(Property, pk=property_id)
    Order.objects.create(
        user=request.user,
        property=property,
        status='pending'
    )
    return redirect('payment_page')
